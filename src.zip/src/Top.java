
public class Top extends CuTop {
	public Top(CuProgr p) {
		super.text = p.toString();
	}
}
