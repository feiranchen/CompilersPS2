
public class CString extends CuExpr {
	String data_s;
	public CString(String s){
		data_s=s;
		super.text=s;
	}
}
