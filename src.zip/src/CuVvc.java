
public class CuVvc {
	protected String text = "";
	@Override public String toString() {
		return text;
	}
}
