public class VTopBot extends CuType {
	String data_s;
	public VTopBot(String s){
		data_s=s;
		super.text=s;
	}
}