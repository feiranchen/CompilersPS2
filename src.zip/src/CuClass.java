import java.util.List;


public abstract class CuClass {
	protected String text = "";
	@Override public String toString() {
		return text;
	}
	public void add(List<CuExpr> s) {
		// TODO Auto-generated method stub
		
	}
	public void add(CuType t) {
		// TODO Auto-generated method stub
		
	}
	public void add(CuStat s) {
		// TODO Auto-generated method stub
		
	}
	public void add(String v, CuTypeScheme ts, CuStat s) {
		// TODO Auto-generated method stub
		
	}
	
}
