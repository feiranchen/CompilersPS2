
public class CuKindContext {
	protected String text = "";
	@Override public String toString() {
		return text;
	}
}
