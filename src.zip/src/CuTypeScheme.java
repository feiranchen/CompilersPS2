
public class CuTypeScheme {
	protected String text = "";
	@Override public String toString() {
		return text;
	}
}
