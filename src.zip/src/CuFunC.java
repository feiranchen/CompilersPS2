
public abstract class CuFunC {
	protected String text = "";
	@Override public String toString() {
		return text;
	}
	public void add(CuVvc v, CuTypeScheme ts) {
		// TODO Auto-generated method stub
		
	}
}
