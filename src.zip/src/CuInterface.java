
public abstract class CuInterface {
	protected String text = "";
	@Override public String toString() {
		return text;
	}
	public void add (CuType tt){};
	public void add (String v_name, CuTypeScheme ts){};
}
