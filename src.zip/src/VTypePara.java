
public class VTypePara extends CuType {
	String data_s;
	public VTypePara(String s){
		data_s=s;
		super.text=s;
	}
}
