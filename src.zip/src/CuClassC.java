import java.util.List;


public abstract class CuClassC {
	protected String text = "";
	@Override public String toString() {
		return text;
	}
	public void add(CuType t) {
		// TODO Auto-generated method stub
		
	}
	public void add(String vv, CuTypeScheme ts) {
		// TODO Auto-generated method stub
		
	}
	public void add(String k, String ci, List<String> kc) {
		// TODO Auto-generated method stub
		
	}
}
