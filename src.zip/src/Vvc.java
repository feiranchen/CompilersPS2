
public class Vvc extends CuVvc{
	public Vvc(String s){
		text=s;
	}
}
