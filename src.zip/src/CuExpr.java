import java.util.List;


public abstract class CuExpr {
	protected String text = "";
	@Override public String toString() {
		return text;
	}
	public void add(List<CuType> pt, List<CuExpr> es) {
		// TODO Auto-generated method stub
		
	}
}
